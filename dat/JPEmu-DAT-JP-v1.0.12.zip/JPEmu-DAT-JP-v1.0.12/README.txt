﻿━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  JPEmu 日本語DAT  説明書
  v1.0.12（2026.11.25）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

■ このDATについて

  日本で発売されたゲームソフトを、日本語のタイトルでまとめた
  DATファイル（ソフトの一覧表）です。形式は OfflineList 形式です。

  ・JPEmu Renamer で、手持ちのROMを正しい日本語の名前に
    リネームするときに使えます。
  ・OfflineList など、OfflineList 形式に対応したソフトでも使えます。
  ・タイトルのほかに、発売日・価格・メーカー・ジャンルも入っています。


■ タイトルの付け方

  できるかぎり、発売当時の正しい名前になるようにしています。

  1. 名前のよりどころ（上ほど優先）
       ① メーカーの公式サイト
          （任天堂の公式ソフト一覧、セガの「セガハード大百科」など）
       ② 日本語版Wikipediaの「○○のゲームタイトル一覧」
     メーカーの公式サイトに載っているソフトは、その書き方に合わせて
     います。公式サイトに無いものは、Wikipediaの書き方に合わせています。
     どちらにも無いものは、検索サイトなどで調べて確かめています。

  2. 読みがな
     「BOXER'S ROAD（ボクサーズロード）」のような読みがなの部分は、
     外しています。

  3. 廉価版・限定版・改訂版など
     ・廉価版、限定版、同梱版などは、それぞれ別の名前で入っています。
       （例：「(廉価版)」「SPECIAL EDITION」「+ジョグコン」）
     ・同じ名前の別の商品は、括弧で区別しています。
       （例：「モナコGP (セガ マイカード)」「コラムス (セガ・ゲーム図書館)」）
     ・ゲームボーイアドバンスとニンテンドーDSで改訂版（不具合を直した版）が
       出ているソフトは、改訂版のCRCにしています。


■ Windowsのファイル名に使えない記号について

  Windowsでは、次の9つの記号をファイル名に使えません。
  リネームしたときに正しく表示できるよう、これらの記号は
  見た目が同じ「全角の記号」に置き換えています。

      もとの記号    →  DATでの記号
         \          →      ＼
         /          →      ／
         :          →      ：
         *          →      ＊
         ?          →      ？
         "          →      ＂
         <          →      ＜
         >          →      ＞
         |          →      ｜

  （例）「らんま1/2」→「らんま1／2」
        「ロックマン3 Dr.ワイリーの最期!?」→「ロックマン3 Dr.ワイリーの最期!？」

  文字が置き換わっているのはこの記号だけで、名前そのものは
  もとのとおりです。


■ CRC（ROMを見分けるための値）について

  ・カートリッジとディスクシステムの機種は、No-Intro のCRCに
    合わせています。
  ・ファミリーコンピュータは、ROMの先頭のヘッダーを除いた値です。
  ・アルカディアは、No-Intro に日本版が無いため、もとになった
    海外版のCRCにしています。
  ・CD-ROMやディスクの機種（セガサターン、メガCD、PCエンジン CD-ROM2、
    PC-FX、3DO、ネオジオCD、プレイディア、ドリームキャスト、
    プレイステーション、プレイステーション2、PSP、ゲームキューブ、
    Wii）と、ネオジオ、ゲーム&ウオッチ、カセットビジョンは、
    CRCが仮の番号になっています。
    この機種は、CRCでの照合（リネーム）には使えません。
    ソフトの一覧として使ってください。


■ 入れていないもの

  ・日本で発売されていないソフト
  ・ニンテンドー3DSの、ダウンロード専用のソフトとダウンロード版
  ・PSPの、配信専用のソフト
  ・No-Intro に吸い出しが無いカートリッジのソフト（64DD、MSX など）
  ・CRCで照合できない商品（ほかの版と中身が同じもの、セット商品など）


■ 収録機種（46機種・21,128本）

  機種                                  本数   ファイル名
  ファミリーコンピュータ                1053   JP_Family Computer.xml
  ファミリーコンピュータ ディスクシステム 202   JP_Family Computer Disk System.xml
  スーパーファミコン                    1446   JP_Super Famicom.xml
  スーファミターボ                        13   JP_Sufami Turbo.xml
  バーチャルボーイ                        19   JP_Virtual Boy.xml
  ゲーム&ウオッチ                         39   JP_Game and Watch.xml
  ゲームボーイ                           781   JP_Game Boy.xml
  ゲームボーイカラー                     476   JP_Game Boy Color.xml
  ゲームボーイアドバンス                 793   JP_Game Boy Advance.xml
  ポケモンミニ                            10   JP_Pokemon Mini.xml
  NINTENDO 64                            198   JP_Nintendo 64.xml
  64DD                                     7   JP_Nintendo 64DD.xml
  ニンテンドーDS                        1846   JP_Nintendo DS.xml
  ニンテンドーDSiウェア                  493   JP_Nintendo DSiWare.xml
  ニンテンドー3DS                        728   JP_Nintendo 3DS.xml
  ニンテンドー ゲームキューブ            275   JP_GameCube.xml
  Wii                                    461   JP_Wii.xml
  SG-1000                                 67   JP_SG-1000.xml
  セガ・マークIII / マスターシステム       84   JP_Master System.xml
  メガドライブ                           450   JP_Mega Drive.xml
  キッズコンピュータ ピコ                223   JP_Sega Pico.xml
  スーパー32X                             18   JP_Super 32X.xml
  ゲームギア                             196   JP_Game Gear.xml
  セガサターン                          1057   JP_Sega Saturn.xml
  ドリームキャスト                       497   JP_Dreamcast.xml
  メガCD                                 116   JP_Mega-CD.xml
  PCエンジン                             280   JP_PC Engine.xml
  PCエンジン スーパーグラフィックス        5   JP_PC Engine SuperGrafx.xml
  PCエンジン CD-ROM2                     122   JP_PC Engine CD-ROM2.xml
  PC-FX                                   62   JP_PC-FX.xml
  ネオジオ                               117   JP_Neo Geo.xml
  ネオジオCD                              97   JP_Neo Geo CD.xml
  ネオジオポケット                         9   JP_Neo Geo Pocket.xml
  ネオジオポケットカラー                  73   JP_Neo Geo Pocket Color.xml
  ワンダースワン                         108   JP_WonderSwan.xml
  ワンダースワンカラー                    90   JP_WonderSwan Color.xml
  プレイステーション                    3358   JP_PlayStation.xml
  プレイステーション2                   2929   JP_PlayStation 2.xml
  PSP                                   1459   JP_PSP.xml
  スーパーカセットビジョン                30   JP_Super Cassette Vision.xml
  カセットビジョン                        11   JP_Cassette Vision.xml
  アルカディア                            15   JP_Arcadia.xml
  MSX                                    438   JP_MSX.xml
  MSX2                                   130   JP_MSX2.xml
  3DO                                    214   JP_3DO.xml
  プレイディア                            33   JP_Playdia.xml


■ 使い方（JPEmu Renamer の場合）

  1. このzipを、好きな場所に展開します。
  2. JPEmu Renamer の「機種の設定」で、ROMの入ったフォルダと、
     その機種のDATファイル（JP_○○.xml）を選びます。
  3. 「リネーム」タブで、変更内容を確かめてから実行します。
     実行したあとも「元に戻す」で戻せます。


■ 利用条件（再配布・二次利用について）

  このDATファイルは、次の条件を守っていただければ、自由に再配布・
  二次利用（ほかのソフトやサイトでの利用、同梱など）していただけます。
  個人で使うだけなら、条件は気にせずお使いください。

  【条件】
  1. 改変しないこと
     DATファイルの中身（タイトル・CRC・発売日など）を書き換えたものを
     配布しないでください。再配布するときは、このzipの中身のまま、
     この説明書（README.txt）も一緒に配布してください。
  2. 営利目的で販売しないこと
     DATファイルそのもの、またはDATファイルを含むものを、有料で
     販売しないでください。
  3. 出典としてHPへのリンクを載せること
     再配布・二次利用するときは、配布ページや説明書などに、
     次のリンクを載せてください。
       JPEmu Project  https://jpemu-project.github.io/

  【そのほかのお願い】
  ・ROMやBIOSと一緒に配布しないでください。
  ・このDATは、正しさをできるかぎり確かめていますが、内容を保証する
    ものではありません。このDATを使ったことで起きたことについて、
    責任は負いかねます。リネームの前には、ROMのバックアップをお取り
    ください。
  ・ゲームのタイトル、メーカー名などは、各社の商標または登録商標です。


■ ご注意

  ・このzipには、ROMやBIOSは入っていません。
    ROMは、ご自身が持っているソフトから吸い出したものをお使いください。
  ・OfflineList の「DATの更新」は使えません（更新先を空にしています）。
    新しい版は、下のサイトからダウンロードしてください。


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  JPEmu Project
  https://jpemu-project.github.io/
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
