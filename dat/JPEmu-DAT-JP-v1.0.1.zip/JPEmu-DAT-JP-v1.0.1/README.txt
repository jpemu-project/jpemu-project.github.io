﻿JPEmu 日本語DAT v1.0.1（2026.11.09）

変更点（v1.0 → v1.0.1）
  ・ファミリーコンピュータ ディスクシステム：10本のCRCを正しい値に直しました（後編など）。
  ・ネオジオポケットカラー：2本のCRCを正しい値に直しました（SNK VS. CAPCOM 頂上決戦 最強ファイターズ、クルクルジャム）。
  ・PCエンジン スーパーグラフィックス：「魔動王グランゾート」の先頭に付いていた「｜」を外しました。

OfflineList形式の日本語DATです。JPEmu Renamer や OfflineList で使えます。
タイトルは、メーカー公式サイトの表記を優先し、無いものは日本語版Wikipediaの
「ゲームタイトル一覧」の表記に合わせています。
Windowsのファイル名に使えない記号（\ / : * ? " < > |）は、全角の同じ記号に置き換えています。

収録機種（22機種）と本数
  ファミリーコンピュータ                 1053  JP_Family Computer.xml
  ファミリーコンピュータ ディスクシステム  202  JP_Family Computer Disk System.xml
  スーパーファミコン                     1447  JP_Super Famicom.xml
  バーチャルボーイ                         19  JP_Virtual Boy.xml
  ゲームボーイ                            781  JP_Game Boy.xml
  ゲームボーイカラー                      476  JP_Game Boy Color.xml
  NINTENDO 64                             198  JP_Nintendo 64.xml
  SG-1000                                  69  JP_SG-1000.xml
  セガ・マークIII / マスターシステム        84  JP_Master System.xml
  メガドライブ                            450  JP_Mega Drive.xml
  スーパー32X                              18  JP_Super 32X.xml
  ゲームギア                              196  JP_Game Gear.xml
  セガサターン                           1057  JP_Sega Saturn.xml
  メガCD                                  116  JP_Mega-CD.xml
  PCエンジン                              280  JP_PC Engine.xml
  PCエンジン スーパーグラフィックス          5  JP_PC Engine SuperGrafx.xml
  PCエンジン CD-ROM2                      122  JP_PC Engine CD-ROM2.xml
  ネオジオ                                117  JP_Neo Geo.xml
  ネオジオポケット                          9  JP_Neo Geo Pocket.xml
  ネオジオポケットカラー                   73  JP_Neo Geo Pocket Color.xml
  ワンダースワン                          108  JP_WonderSwan.xml
  ワンダースワンカラー                     90  JP_WonderSwan Color.xml

ゲームボーイアドバンス、ニンテンドーDS、DSiウェア、ニンテンドー3DS、
プレイステーションのDATは、確認が終わりしだい公開します。

ROMは、ご自身で吸い出したものをお使いください。
https://jpemu-project.github.io/
